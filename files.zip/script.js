const KEY = 'datavault.entries';
let entries = [];
let editingId = null;
let activeCat = 'All';

const $ = (id) => document.getElementById(id);
const form = $('entryForm');
const grid = $('grid');

/* ---------- storage ---------- */
function loadEntries() {
  try {
    entries = JSON.parse(localStorage.getItem(KEY)) || [];
  } catch (e) {
    entries = [];
  }
}

function saveEntries() {
  try {
    localStorage.setItem(KEY, JSON.stringify(entries));
  } catch (e) {
    showError('Could not save: browser storage is unavailable or full.');
  }
}

/* ---------- helpers ---------- */
function showError(msg) {
  $('error').textContent = msg || '';
}

function formatDate(iso) {
  return new Date(iso).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
}

/* ---------- render ---------- */
function renderEntries() {
  const q = $('search').value.trim().toLowerCase();
  const list = entries
    .filter((e) => activeCat === 'All' || e.category === activeCat)
    .filter((e) => (e.title + ' ' + e.details).toLowerCase().includes(q))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  grid.innerHTML = '';
  if (!list.length) {
    const p = document.createElement('p');
    p.className = 'empty';
    p.textContent = entries.length ? 'No matches.' : 'Nothing saved yet. Add your first entry above.';
    grid.appendChild(p);
    return;
  }

  list.forEach((e) => {
    const card = document.createElement('article');
    card.className = 'card glass';
    card.dataset.id = e.id;

    const badge = document.createElement('span');
    badge.className = 'badge';
    badge.textContent = e.category;

    const h = document.createElement('h3');
    h.textContent = e.title;

    const p = document.createElement('p');
    p.textContent = e.details;

    const t = document.createElement('time');
    t.textContent = formatDate(e.createdAt);

    const actions = document.createElement('div');
    actions.className = 'actions';
    const edit = document.createElement('button');
    edit.className = 'btn';
    edit.textContent = 'Edit';
    edit.onclick = () => editEntry(e.id);
    const del = document.createElement('button');
    del.className = 'btn';
    del.textContent = 'Delete';
    del.onclick = () => deleteEntry(e.id, card);
    actions.append(edit, del);

    card.append(badge, h, p, t, actions);
    grid.appendChild(card);
  });
}

/* ---------- actions ---------- */
function addEntry(title, category, details) {
  if (editingId) {
    const e = entries.find((x) => x.id === editingId);
    if (e) Object.assign(e, { title, category, details });
    editingId = null;
    $('addBtn').textContent = 'Add';
  } else {
    entries.push({
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      title, category, details,
      createdAt: new Date().toISOString(),
    });
  }
  saveEntries();
  renderEntries();
}

function deleteEntry(id, card) {
  card.classList.add('removing');
  setTimeout(() => {
    entries = entries.filter((e) => e.id !== id);
    saveEntries();
    renderEntries();
  }, 300);
}

function editEntry(id) {
  const e = entries.find((x) => x.id === id);
  if (!e) return;
  $('title').value = e.title;
  $('category').value = e.category;
  $('details').value = e.details;
  editingId = id;
  $('addBtn').textContent = 'Save changes';
  $('title').focus();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

/* ---------- import / export ---------- */
function exportEntries() {
  const blob = new Blob([JSON.stringify(entries, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'datavault-export.json';
  a.click();
  URL.revokeObjectURL(a.href);
}

function importEntries(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      if (!Array.isArray(data)) throw new Error('bad format');
      const ids = new Set(entries.map((e) => e.id));
      data.forEach((e) => {
        if (e && e.title && !ids.has(e.id)) {
          entries.push({
            id: e.id || Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
            title: String(e.title),
            category: e.category || 'Notes',
            details: String(e.details || ''),
            createdAt: e.createdAt || new Date().toISOString(),
          });
        }
      });
      saveEntries();
      renderEntries();
      showError('');
    } catch (err) {
      showError('That file is not a valid DataVault JSON export.');
    }
  };
  reader.readAsText(file);
}

/* ---------- events ---------- */
form.addEventListener('submit', (ev) => {
  ev.preventDefault();
  const title = $('title').value.trim();
  if (!title) {
    showError('Please enter a title.');
    $('title').focus();
    return;
  }
  showError('');
  addEntry(title, $('category').value, $('details').value.trim());
  form.reset();
});

$('search').addEventListener('input', renderEntries);
$('exportBtn').addEventListener('click', exportEntries);
$('importFile').addEventListener('change', (ev) => {
  if (ev.target.files[0]) importEntries(ev.target.files[0]);
  ev.target.value = '';
});
$('filters').addEventListener('click', (ev) => {
  const btn = ev.target.closest('.chip');
  if (!btn) return;
  activeCat = btn.dataset.cat;
  document.querySelectorAll('.chip').forEach((c) => c.classList.toggle('active', c === btn));
  renderEntries();
});

loadEntries();
renderEntries();
